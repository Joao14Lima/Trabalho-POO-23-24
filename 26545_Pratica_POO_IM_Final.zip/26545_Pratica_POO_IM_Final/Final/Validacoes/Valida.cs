﻿/*
    Trabalho Pratico

    Programação Orientada a Objetos (POO)

    João Lima | 2ºANO | LEIM

 */

namespace Validacoes
{
    [Serializable]
    /// <summary>
    /// Classe que fornece métodos para validar informações relacionadas a ocorrências e bombeiros.
    /// </summary>
    public class Valida
    {

        #region OtherMethods Ocorrencia
        /// <summary>
        /// Verifica se o ID da ocorrência é válido.
        /// </summary>
        /// <param name="ido">ID da ocorrência a ser validado.</param>
        /// <returns>True se o ID é válido, False caso contrário.</returns>
        public static bool IdOcrValido(int ido)
        {
            return (ido > 0 && ido < 1000);
        }

        /// <summary>
        /// Verifica se a localização da ocorrência é válida.
        /// </summary>
        /// <param name="nome">Localização da ocorrência a ser validada.</param>
        /// <returns>True se a localização é válida, False caso contrário.</returns>
        public static bool LocalizacaoOcrValida(string nome)
        {
            // Verifica se o comprimento do nome está entre 1 e 120 caracteres
            return !string.IsNullOrEmpty(nome) && nome.Length <= 120;
        }

        /// <summary>
        /// Verifica se o nível de gravidade da ocorrência é válido.
        /// </summary>
        /// <param name="nvl">Nível de gravidade da ocorrência a ser validado.</param>
        /// <returns>True se o nível é válido, False caso contrário.</returns>
        public static bool NivelOcrValido(int nvl)
        {
            return (nvl > 1 && nvl < 5);
        }
        #endregion

        #region OtherMethods Bombeiro
        /// <summary>
        /// Verifica se o ID do bombeiro é válido.
        /// </summary>
        /// <param name="idb">ID do bombeiro a ser validado.</param>
        /// <returns>True se o ID é válido, False caso contrário.</returns>
        public static bool IdBombValido(int idb)
        {
            return (idb > 0 && idb < 1000);
        }

        /// <summary>
        /// Verifica se o nome do bombeiro é válido.
        /// </summary>
        /// <param name="nome">Nome do bombeiro a ser validado.</param>
        /// <returns>True se o nome é válido, False caso contrário.</returns>
        public static bool NomeBombValido(string nome)
        {
            // Verifica se o comprimento do nome está entre 1 e 120 caracteres
            return !string.IsNullOrEmpty(nome) && nome.Length <= 120;
        }

        /// <summary>
        /// Verifica se a idade do bombeiro é válida.
        /// </summary>
        /// <param name="idade">Idade do bombeiro a ser validada.</param>
        /// <returns>True se a idade é válida, False caso contrário.</returns>
        public static bool IdadeBombValida(int idade)
        {
            return (idade > 0 && idade < 100);
        }

        /// <summary>
        /// Verifica se o contacto do bombeiro é válido.
        /// </summary>
        /// <param name="cont">Número de contacto do bombeiro a ser validado.</param>
        /// <returns>True se o contacto é válido, False caso contrário.</returns>
        public static bool ContactoBombValido(int cont)
        {
            return (cont > 900000000 && cont < 999999999);
        }
        #endregion

    }
}