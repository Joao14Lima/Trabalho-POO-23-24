﻿/*
    Trabalho Pratico

    Programação Orientada a Objetos (POO)

    João Lima | 2ºANO | LEIM

 */

using ObjetosNegocio;
using Dados;

namespace RegrasDeNegocio
{
    [Serializable]
    public class GereQuartel
    {
        #region Ocorrencia
        /// <summary>
        /// Insere uma ocorrência com validação de dados.
        /// </summary>
        /// <param name="id">Identificador da ocorrência.</param>
        /// <param name="o">Objeto Ocorrencia a ser inserido.</param>
        /// <returns>Verdadeiro se a inserção for bem-sucedida; falso caso contrário.</returns>
        /// <exception cref="Exception">Exceção lançada se os dados forem inválidos.</exception>
        public static bool InsereOcorrencia(int id, Ocorrencia o)
        {
            if ((o.Id > 0 && o.Id < 1000) && (!string.IsNullOrEmpty(o.Localizacao) && o.Localizacao.Length <= 120) && (o.Nivel >= 1 && o.Nivel <= 5))
            {
                return Central.InsereOcorrencia(id, o);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Insere uma ocorrência sem especificar o ID, com validação de dados.
        /// </summary>
        /// <param name="o">Objeto Ocorrencia a ser inserido.</param>
        /// <returns>Verdadeiro se a inserção for bem-sucedida; falso caso contrário.</returns>
        /// <exception cref="Exception">Exceção lançada se os dados forem inválidos.</exception>
        public static bool InsereOcorrenciaSemId(Ocorrencia o)
        {
            if ((o.Id > 0 && o.Id < 1000) && (!string.IsNullOrEmpty(o.Localizacao) && o.Localizacao.Length <= 120) && (o.Nivel >= 1 && o.Nivel <= 5))
            {
                return Central.InsereOcorrenciaSemId(o);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Remove uma ocorrência com validação de dados.
        /// </summary>
        /// <param name="id">Identificador da ocorrência.</param>
        /// <param name="o">Objeto Ocorrencia a ser removido.</param>
        /// <returns>Verdadeiro se a remoção for bem-sucedida; falso caso contrário.</returns>
        /// <exception cref="Exception">Exceção lançada se os dados forem inválidos ou se a ocorrência não existir.</exception>
        public static bool RemoveOcorrencia(int id, Ocorrencia o)
        {
            // Validate occurrence data before removing
            if ((o.Id > 0 && o.Id < 1000) && (!string.IsNullOrEmpty(o.Localizacao) && o.Localizacao.Length <= 120) && (o.Nivel >= 1 && o.Nivel <= 5))
            {
                // Check if the occurrence exists and is equal to the provided occurrence
                if (Central.ExisteOcorrencia(id, o))
                {
                    return Central.RemoveOcorrencia(id, o);
                }

                throw new Exception("A Ocorrência a remover não existe ou não é igual à fornecida.");
            }

            throw new Exception("Dados Inválidos para a Ocorrência");
        }

        /// <summary>
        /// Verifica se uma ocorrência existe.
        /// </summary>
        /// <param name="id">Identificador da ocorrência.</param>
        /// <param name="o">Objeto Ocorrencia a ser verificado.</param>
        /// <returns>Verdadeiro se a ocorrência existir; falso caso contrário.</returns>
        public static bool ExisteOcorrencia(int id, Ocorrencia o)
        {
            // Adicione lógica para verificar se a ocorrência existe
            return Central.ExisteOcorrencia(id, o);
        }

        /// <summary>
        /// Salva as ocorrências em um arquivo binário.
        /// </summary>
        /// <param name="fileName">O nome do arquivo no qual as ocorrências serão salvas.</param>
        /// <returns>Retorna verdadeiro se a operação de salvamento for bem-sucedida, falso se não for.</returns>
        public static bool SalvaOcorrencia(string fileName)
        {
            return Central.SalvaOcorrencia(fileName);
        }

        /// <summary>
        /// Método estático que exibe no console todas as informações das Ocorrências presentes no dicionário.
        /// </summary>
        public static void MostraTodasAsOcorrencias()
        {
            Central.ShowDictinaryOcorrencia();
        }
        #endregion

        #region Bombeiro
        /// <summary>
        /// Insere um bombeiro com validação de dados.
        /// </summary>
        /// <param name="id">Identificador do bombeiro.</param>
        /// <param name="b">Objeto Bombeiro a ser inserido.</param>
        /// <returns>Verdadeiro se a inserção for bem-sucedida; falso caso contrário.</returns>
        /// <exception cref="Exception">Exceção lançada se os dados forem inválidos.</exception>
        public static bool InsereBombeiro(int id, Bombeiro b)
        {
            if ((b.Id > 0 && b.Id < 1000) && (!string.IsNullOrEmpty(b.Nome) && b.Nome.Length <= 120) && (b.Idade > 0 && b.Idade < 100) && (b.Contacto >= 900000000 && b.Contacto <= 999999999))
            {
                return Colaboradores.InsereBombeiro(id, b);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Insere um bombeiro sem especificar o ID, com validação de dados.
        /// </summary>
        /// <param name="b">Objeto Bombeiro a ser inserido.</param>
        /// <returns>Verdadeiro se a inserção for bem-sucedida; falso caso contrário.</returns>
        /// <exception cref="Exception">Exceção lançada se os dados forem inválidos.</exception>
        public static bool InsereBombeiroSemId(Bombeiro b)
        {
            if ((b.Id > 0 && b.Id < 1000) && (!string.IsNullOrEmpty(b.Nome) && b.Nome.Length <= 120) && (b.Idade > 0 && b.Idade < 100) && (b.Contacto >= 900000000 && b.Contacto <= 999999999))
            {
                return Colaboradores.InsereBombeiroSemId(b);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Remove um bombeiro com validação de dados.
        /// </summary>
        /// <param name="id">Identificador do bombeiro.</param>
        /// <param name="b">Objeto Bombeiro a ser removido.</param>
        /// <returns>Verdadeiro se a remoção for bem-sucedida; falso caso contrário.</returns>
        /// <exception cref="Exception">Exceção lançada se os dados forem inválidos ou se o bombeiro não existir.</exception>
        public static bool RemoveBombeiro(int id, Bombeiro b)
        {
            // Validate occurrence data before removing
            if (b.Id >= 1 && b.Idade >= 18 && b.Contacto >= 900000000 && b.Contacto <= 999999999)
            {
                // Check if the occurrence exists and is equal to the provided occurrence
                if (Colaboradores.ExisteBombeiro(id, b))
                {
                    return Colaboradores.RemoveBombeiro(id, b);
                }

                throw new Exception("O Bombeiro a remover não existe ou não é igual à fornecida.");
            }

            throw new Exception("Dados Inválidos para o Bombeiro");
        }

        /// <summary>
        /// Verifica se um bombeiro existe.
        /// </summary>
        /// <param name="id">Identificador do bombeiro.</param>
        /// <param name="b">Objeto Bombeiro a ser verificado.</param>
        /// <returns>Verdadeiro se o bombeiro existir; falso caso contrário.</returns>
        public static bool ExisteBombeiro(int id, Bombeiro b)
        {
            // Adicione lógica para verificar se a ocorrência existe
            return Colaboradores.ExisteBombeiro(id, b);
        }

        /// <summary>
        /// Guarda as informações dos bombeiros num ficheiro no formato binário.
        /// </summary>
        /// <param name="fileName">O nome do arquivo no qual os bombeiros serão salvos.</param>
        /// <returns>Retorna verdadeiro se a operação de salvamento for bem-sucedida, falso se não for.</returns>
        public static bool SalvaBombeiro(string fileName)
        {
            return Colaboradores.SalvaBombeiro(fileName);
        }

        /// <summary>
        /// Método estático que exibe no console todas as informações dos Bombeiros presentes no dicionário.
        /// </summary>
        public static void MostraTodosOsBombeiros()
        {
            Colaboradores.ShowDictinaryBombeiros();
        }
        #endregion

        #region Bombeiro Profissional
        /// <summary>
        /// Insere um bombeiro profissional na coleção se os dados fornecidos forem válidos.
        /// </summary>
        /// <param name="id">ID do bombeiro profissional a ser inserido.</param>
        /// <param name="bp">Instância do bombeiro profissional a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos.</exception>
        public static bool InsereBombeiroProfissional(int id, BombeiroProfissional bp)
        {
            if ((bp.Id > 0 && bp.Id < 1000) && (!string.IsNullOrEmpty(bp.Nome) && bp.Nome.Length <= 120) && (bp.Idade > 0 && bp.Idade < 100) && (bp.Contacto >= 900000000 && bp.Contacto <= 999999999))
            {
                return Colaboradores.InsereBombeiroProfissional(id, bp);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Insere um bombeiro profissional na coleção se os dados fornecidos forem válidos.
        /// </summary>
        /// <param name="bp">Instância do bombeiro profissional a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos.</exception>
        public static bool InsereBombeiroProfissionalSemId(BombeiroProfissional bp)
        {
            if ((bp.Id > 0 && bp.Id < 1000) && (!string.IsNullOrEmpty(bp.Nome) && bp.Nome.Length <= 120) && (bp.Idade > 0 && bp.Idade < 100) && (bp.Contacto >= 900000000 && bp.Contacto <= 999999999))
            {
                return Colaboradores.InsereBombeiroProfissionalSemId(bp);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Remove um bombeiro profissional da coleção se os dados fornecidos forem válidos e o bombeiro existir.
        /// </summary>
        /// <param name="id">ID do bombeiro profissional a ser removido.</param>
        /// <param name="bp">Instância do bombeiro profissional a ser removido.</param>
        /// <returns>Retorna verdadeiro se a operação de remoção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos ou se o bombeiro a ser removido não existir.</exception>
        public static bool RemoveBombeiroProfissional(int id, BombeiroProfissional bp)
        {
            if (bp.Id >= 1 && bp.Idade >= 18 && bp.Contacto >= 900000000 && bp.Contacto <= 999999999)
            {
                if (Colaboradores.ExisteBombeiroProfissional(id, bp))
                {
                    return Colaboradores.RemoveBombeiroProfissional(id, bp);
                }

                throw new Exception("O Bombeiro Profissional a remover não existe ou não é igual à fornecida.");
            }

            throw new Exception("Dados Inválidos para o Bombeiro Profissional");
        }

        /// <summary>
        /// Verifica se um bombeiro profissional com o ID fornecido existe e é igual à instância fornecida.
        /// </summary>
        /// <param name="id">ID do bombeiro profissional a ser verificado.</param>
        /// <param name="bp">Instância do bombeiro profissional a ser comparada.</param>
        /// <returns>Retorna verdadeiro se o bombeiro profissional com o ID fornecido existe e é igual à instância fornecida.</returns>
        /// <exception cref="Exception">Lança uma exceção se o bombeiro profissional não existir.</exception>
        public static bool ExisteBombeiroProfissional(int id, BombeiroProfissional bp)
        {
            // Adicione lógica para verificar se a ocorrência existe
            return Colaboradores.ExisteBombeiroProfissional(id, bp);
        }

        /// <summary>
        /// Salva os dados dos bombeiros profissionais em um arquivo binário.
        /// </summary>
        /// <param name="fileName">Nome do arquivo para salvar os dados dos bombeiros profissionais.</param>
        /// <returns>Retorna verdadeiro se a operação de salvamento for bem-sucedida, falso se não for.</returns>
        public static bool SalvaBombeiroProfissional(string fileName)
        {
            return Colaboradores.SalvaBombeiroProfissional(fileName);
        }

        /// <summary>
        /// Método estático que exibe no console todas as informações dos Bombeiros Profissionais presentes no dicionário.
        /// </summary>
        public static void MostraTodosOsBombeirosProfissionais()
        {
            Colaboradores.ShowDictinaryBombeiroProfissional();
        }
        #endregion

        #region Bombeiro Voluntario
        /// <summary>
        /// Insere um bombeiro voluntário na coleção se os dados fornecidos forem válidos.
        /// </summary>
        /// <param name="id">ID do bombeiro voluntário a ser inserido.</param>
        /// <param name="bv">Instância do bombeiro voluntário a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos.</exception>
        public static bool InsereBombeiroVoluntario(int id, BombeiroVoluntario bv)
        {
            if ((bv.Id > 0 && bv.Id < 1000) && (!string.IsNullOrEmpty(bv.Nome) && bv.Nome.Length <= 120) && (bv.Idade > 0 && bv.Idade < 100) && (bv.Contacto >= 900000000 && bv.Contacto <= 999999999) && bv.NumeroVoluntario >= 1)
            {
                return Colaboradores.InsereBombeiroVoluntario(id, bv);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Insere um bombeiro voluntário na coleção se os dados fornecidos forem válidos.
        /// </summary>
        /// <param name="bv">Instância do bombeiro voluntário a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos.</exception>
        public static bool InsereBombeiroVoluntarioSemId(BombeiroVoluntario bv)
        {
            if ((bv.Id > 0 && bv.Id < 1000) && (!string.IsNullOrEmpty(bv.Nome) && bv.Nome.Length <= 120) && (bv.Idade > 0 && bv.Idade < 100) && (bv.Contacto >= 900000000 && bv.Contacto <= 999999999) && bv.NumeroVoluntario >= 1)
            {
                return Colaboradores.InsereBombeiroVoluntarioSemId(bv);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Remove um bombeiro voluntário da coleção se os dados fornecidos forem válidos e o bombeiro existir.
        /// </summary>
        /// <param name="id">ID do bombeiro voluntário a ser removido.</param>
        /// <param name="bv">Instância do bombeiro voluntário a ser removido.</param>
        /// <returns>Retorna verdadeiro se a operação de remoção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos ou se o bombeiro a ser removido não existir.</exception>
        public static bool RemoveBombeiroVoluntario(int id, BombeiroVoluntario bv)
        {
            if ((bv.Id > 0 && bv.Id < 1000) && (!string.IsNullOrEmpty(bv.Nome) && bv.Nome.Length <= 120) && (bv.Idade > 0 && bv.Idade < 100) && (bv.Contacto >= 900000000 && bv.Contacto <= 999999999) && bv.NumeroVoluntario >= 1)
            {
                if (Colaboradores.ExisteBombeiroVoluntario(id, bv))
                {
                    return Colaboradores.RemoveBombeiroVoluntario(id, bv);
                }

                throw new Exception("O Bombeiro Voluntario a remover não existe ou não é igual à fornecida.");
            }

            throw new Exception("Dados Inválidos para o Bombeiro Voluntario");
        }

        /// <summary>
        /// Verifica se um bombeiro voluntário com o ID fornecido existe e é igual à instância fornecida.
        /// </summary>
        /// <param name="id">ID do bombeiro voluntário a ser verificado.</param>
        /// <param name="bv">Instância do bombeiro voluntário a ser comparada.</param>
        /// <returns>Retorna verdadeiro se o bombeiro voluntário com o ID fornecido existe e é igual à instância fornecida.</returns>
        public static bool ExisteBombeiroVoluntario(int id, BombeiroVoluntario bv)
        {
            return Colaboradores.ExisteBombeiroVoluntario(id, bv);
        }

        /// <summary>
        /// Salva os dados dos bombeiros voluntários em um arquivo binário.
        /// </summary>
        /// <param name="fileName">Nome do arquivo para salvar os dados dos bombeiros voluntários.</param>
        /// <returns>Retorna verdadeiro se a operação de salvamento for bem-sucedida, falso se não for.</returns>
        public static bool SalvaBombeiroVoluntario(string fileName)
        {
            return Colaboradores.SalvaBombeiroVoluntario(fileName);
        }

        /// <summary>
        /// Método estático que exibe no console todas as informações dos Bombeiros Voluntários presentes no dicionário.
        /// </summary>
        public static void MostraTodosOsBombeirosVoluntarios()
        {
            Colaboradores.ShowDictinaryBombeiroVoluntario();
        }
        #endregion

        #region Bombeiro Privativo
        /// <summary>
        /// Insere um bombeiro privativo na coleção se os dados fornecidos forem válidos.
        /// </summary>
        /// <param name="id">ID do bombeiro privativo a ser inserido.</param>
        /// <param name="bpv">Instância do bombeiro privativo a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos.</exception>
        public static bool InsereBombeiroPrivativo(int id, BombeiroPrivativo bpv)
        {
            if ((bpv.Id > 0 && bpv.Id < 1000) && (!string.IsNullOrEmpty(bpv.Nome) && bpv.Nome.Length <= 120) && (bpv.Idade > 0 && bpv.Idade < 100) && (bpv.Contacto >= 900000000 && bpv.Contacto <= 999999999) && (!string.IsNullOrEmpty(bpv.Empresa) && bpv.Empresa.Length <= 120))
            {
                return Colaboradores.InsereBombeiroPrivativo(id, bpv);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Insere um bombeiro privativo na coleção se os dados fornecidos forem válidos.
        /// </summary>
        /// <param name="bpv">Instância do bombeiro privativo a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos.</exception>
        public static bool InsereBombeiroPrivativoSemId(BombeiroPrivativo bpv)
        {
            if ((bpv.Id > 0 && bpv.Id < 1000) && (!string.IsNullOrEmpty(bpv.Nome) && bpv.Nome.Length <= 120) && (bpv.Idade > 0 && bpv.Idade < 100) && (bpv.Contacto >= 900000000 && bpv.Contacto <= 999999999) && (!string.IsNullOrEmpty(bpv.Empresa) && bpv.Empresa.Length <= 120))
            {
                return Colaboradores.InsereBombeiroPrivativoSemId(bpv);
            }
            throw new Exception("Dados Invalidos");
        }

        /// <summary>
        /// Remove um bombeiro privativo da coleção se os dados fornecidos forem válidos e o bombeiro existir.
        /// </summary>
        /// <param name="id">ID do bombeiro privativo a ser removido.</param>
        /// <param name="bpv">Instância do bombeiro privativo a ser removido.</param>
        /// <returns>Retorna verdadeiro se a operação de remoção for bem-sucedida, falso se não for.</returns>
        /// <exception cref="Exception">Lança uma exceção se os dados fornecidos forem inválidos ou se o bombeiro a ser removido não existir.</exception>
        public static bool RemoveBombeiroPrivativo(int id, BombeiroPrivativo bpv)
        {
            if ((bpv.Id > 0 && bpv.Id < 1000) && (!string.IsNullOrEmpty(bpv.Nome) && bpv.Nome.Length <= 120) && (bpv.Idade > 0 && bpv.Idade < 100) && (bpv.Contacto >= 900000000 && bpv.Contacto <= 999999999) && (!string.IsNullOrEmpty(bpv.Empresa) && bpv.Empresa.Length <= 120))
            {
                if (Colaboradores.ExisteBombeiroPrivativo(id, bpv))
                {
                    return Colaboradores.RemoveBombeiroPrivativo(id, bpv);
                }

                throw new Exception("O Bombeiro Privativo a remover não existe ou não é igual à fornecida.");
            }

            throw new Exception("Dados Inválidos para o Bombeiro Privativo");
        }

        /// <summary>
        /// Verifica se um bombeiro privativo com o ID fornecido existe e é igual à instância fornecida.
        /// </summary>
        /// <param name="id">ID do bombeiro privativo a ser verificado.</param>
        /// <param name="bpv">Instância do bombeiro privativo a ser comparada.</param>
        /// <returns>Retorna verdadeiro se o bombeiro privativo com o ID fornecido existe e é igual à instância fornecida.</returns>
        /// <exception cref="Exception">Lança uma exceção se o bombeiro privativo não existir.</exception>
        public static void ExisteBombeiroPrivativol(int id, BombeiroPrivativo bpv)
        {
            Colaboradores.ExisteBombeiroPrivativo(id, bpv);
        }

        /// <summary>
        /// Salva os dados dos bombeiros privativos em um arquivo binário.
        /// </summary>
        /// <param name="fileName">Nome do arquivo para salvar os dados dos bombeiros privativos.</param>
        /// <returns>Retorna verdadeiro se a operação de salvamento for bem-sucedida, falso se não for.</returns>
        public static bool SalvaBombeiroPrivativo(string fileName)
        {
            return Colaboradores.SalvaBombeiroPrivativo(fileName);
        }

        /// <summary>
        /// Método estático que exibe no console todas as informações dos Bombeiros Privativos presentes no dicionário.
        /// </summary>
        public static void MostraTodosOsBombeirosPrivativos()
        {
            Colaboradores.ShowDictinaryBombeiroPrivativo();
        }
        #endregion
    }
}
