﻿/*
    Trabalho Pratico

    Programação Orientada a Objetos (POO)

    João Lima | 2ºANO | LEIM

 */

/// <summary>
/// Enumeração que representa diferentes especializações para bombeiros profissionais.
/// </summary>
public enum TipoEspecializacao
{
    Psicologo,  //Apoio Psicossocial e Socorro Psicológico
    Motorista,  //Condução e Manutenção de Veículos 
    Cinotecnia,   //Manejo e treinamento de cães para trabalhos específicos civis ou militares
    Enfermeiro,     //Emergência Pré-Hospitalar
    Mergulhador,    //Socorros a Náufragos e Buscas Subaquáticas
    TecnicoDeInformática,   //Tecnologias de Informação e Comunicação
    Fanfarrista     //Banda e Fanfarra

}

namespace ObjetosNegocio
{
    [Serializable]
    /// <summary>
    /// Classe que representa um bombeiro genérico.
    /// </summary>
    public class Bombeiro
    {
        #region Attributes
        /// <summary>
        /// Identificação única do bombeiro.
        /// Nome do bombeiro.
        /// Idade do bombeiro.
        /// Número de contacto do bombeiro.
        /// </summary>
        protected int id;
        protected string nome;
        protected int idade;
        protected int contacto;

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor padrão que inicializa os atributos com valores padrão.
        /// </summary>
        public Bombeiro()
        {
            id = 0;
            nome = "";
            idade = 0;
            contacto = 0;
        }

        /// <summary>
        /// Construtor que permite a inicialização dos atributos com valores específicos.
        /// </summary>
        /// <param name="id">Identificação única do bombeiro.</param>
        /// <param name="nome">Nome do bombeiro.</param>
        /// <param name="idade">Idade do bombeiro.</param>
        /// <param name="contacto">Número de contacto do bombeiro.</param>
        public Bombeiro(int id, string nome, int idade, int contacto)
        {
            this.id = id;
            this.nome = nome;
            this.idade = idade;
            this.contacto = contacto;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Propriedade para aceder ou modificar a identificação do bombeiro.
        /// </summary>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Propriedade para aceder ou modificar o nome do bombeiro.
        /// </summary>
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        /// <summary>
        /// Propriedade para aceder ou modificar a idade do bombeiro.
        /// </summary>
        public int Idade
        {
            get { return idade; }
            set { idade = value; }
        }

        /// <summary>
        /// Propriedade para aceder ou modificar o número de contacto do bombeiro.
        /// </summary>
        public int Contacto
        {
            get { return contacto; }
            set { contacto = value; }
        }
        #endregion

        #region Overrides
        /// <summary>
        /// Obtém uma representação de string do objeto Bombeiro.
        /// </summary>
        /// <returns>String formatada representando as informações do bombeiro.</returns>
        public override string ToString()
        {
            return String.Format("Ficha Bombeiro =>ID: {0} | Nome: {1} | Idade: {2} | Contacto: {3}\n", Id, Nome, Idade, Contacto);
        }

        /// <summary>
        /// Verifica se dois bombeiros são iguais, comparando os seus atributos.
        /// </summary>
        /// <param name="obj">Objeto a ser comparado.</param>
        /// <returns>True se os bombeiros são iguais, False caso contrário.</returns>
        public override bool Equals(object? obj)
        {
            if (obj == null || !(obj is Bombeiro))
            {
                return false;
            }

            Bombeiro aux = (Bombeiro)obj;
            if (id == aux.id && System.String.Equals(nome, aux.nome) && idade == aux.idade && contacto == aux.contacto)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Obtém um código hash único para o bombeiro.
        /// </summary>
        /// <returns>Código hash.</returns>
        public override int GetHashCode()
        {
            return id.GetHashCode();
        }
        #endregion

        #region OtherMethods

        #endregion
        #endregion

    }

    [Serializable]
    /// <summary>
    /// Classe que representa um bombeiro profissional, derivada da classe Bombeiro.
    /// </summary>
    public class BombeiroProfissional : Bombeiro
    {
        #region Attributes
        /// <summary>
        /// Tipo de especialização do bombeiro profissional.
        /// </summary>
        private TipoEspecializacao tipoesp;

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor padrão que inicializa o tipo de especialização como Fanfarrista.
        /// </summary>
        public BombeiroProfissional()
        {
            tipoesp = TipoEspecializacao.Fanfarrista;
        }

        /// <summary>
        /// Construtor que permite a inicialização dos atributos com valores específicos.
        /// </summary>
        /// <param name="id">Identificação única do bombeiro.</param>
        /// <param name="nome">Nome do bombeiro.</param>
        /// <param name="idade">Idade do bombeiro.</param>
        /// <param name="tipoesp">Tipo de especialização do bombeiro profissional.</param>
        /// <param name="contacto">Número de contacto do bombeiro.</param>
        public BombeiroProfissional(int id, string nome, int idade, TipoEspecializacao tipoesp, int contacto)
        {
            Id = id;
            Nome = nome;
            Idade = idade;
            this.tipoesp = tipoesp;
            Contacto = contacto;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Propriedade para aceder ou modificar o tipo de especialização do bombeiro profissional.
        /// </summary>
        public TipoEspecializacao Tipoesp
        {
            get { return tipoesp; }
            set { tipoesp = value; }
        }
        #endregion

        #region Overrides
        /// <summary>
        /// Obtém uma representação de string do objeto Bombeiro Profissional.
        /// </summary>
        /// <returns>String formatada representando as informações do bombeiro profissional.</returns>
        public override string ToString()
        {
            return String.Format("Ficha Bombeiro Profissional =>ID: {0} | Nome: {1} | Idade: {2} | Tipo especialidade: {3} | Contacto: {4}\n", Id, Nome, Idade, Tipoesp, Contacto);
        }

        /// <summary>
        /// Verifica se dois bombeiros são iguais, comparando os seus atributos.
        /// </summary>
        /// <param name="obj">Objeto a ser comparado.</param>
        /// <returns>True se os bombeiros são iguais, False caso contrário.</returns>
        public override bool Equals(object? obj)
        {
            if (obj == null || !(obj is BombeiroProfissional))
            {
                return false;
            }

            BombeiroProfissional aux = (BombeiroProfissional)obj;
            if (id == aux.id && System.String.Equals(nome, aux.nome) && idade == aux.idade && tipoesp == aux.tipoesp && contacto == aux.contacto)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Obtém um código hash único para o bombeiro.
        /// </summary>
        /// <returns>Código hash.</returns>
        public override int GetHashCode()
        {
            return id.GetHashCode();
        }
        #endregion

        #region OtherMethods
        #endregion

        #endregion
    }

    [Serializable]
    /// <summary>
    /// Classe que representa um bombeiro voluntário, derivada da classe Bombeiro.
    /// </summary>
    public class BombeiroVoluntario : Bombeiro
    {
        #region Attributes
        /// <summary>
        /// Número de voluntário do bombeiro voluntário.
        /// </summary>
        private int numerovoluntario;

        #endregion

        #region Methods

        #region Constructors
        /// <summary>
        /// Construtor padrão que inicializa o número de voluntário como 1.
        /// </summary>
        public BombeiroVoluntario()
        {
            id = 0;
            nome = "";
            idade = 0;
            numerovoluntario = 1;
            contacto = 0;
        }

        /// <summary>
        /// Construtor que permite a inicialização dos atributos com valores específicos.
        /// </summary>
        /// <param name="id">Identificação única do bombeiro.</param>
        /// <param name="nome">Nome do bombeiro.</param>
        /// <param name="idade">Idade do bombeiro.</param>
        /// <param name="nv">Número de voluntário do bombeiro voluntário.</param>
        /// <param name="contacto">Número de contacto do bombeiro.</param>
        public BombeiroVoluntario(int id, string nome, int idade, int nv, int contacto)
        {
            this.id = id;
            this.nome = nome;
            this.idade = idade;
            numerovoluntario = nv;
            this.contacto = contacto;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Propriedade para aceder ou modificar o número de voluntário do bombeiro voluntário.
        /// </summary>
        public int NumeroVoluntario
        {
            get { return numerovoluntario; }
            set { numerovoluntario = value; }
        }
        #endregion

        #region Overrides
        /// <summary>
        /// Obtém uma representação de string do objeto Bombeiro Voluntario.
        /// </summary>
        /// <returns>String formatada representando as informações do bombeiro Voluntario.</returns>
        public override string ToString()
        {
            return String.Format("Ficha Bombeiro Voluntario =>ID: {0} | Nome: {1} | Idade: {2} | Numero Voluntario: {3} | Contacto: {4}\n", Id, Nome, Idade, NumeroVoluntario, Contacto);
        }

        /// <summary>
        /// Verifica se dois bombeiros são iguais, comparando os seus atributos.
        /// </summary>
        /// <param name="obj">Objeto a ser comparado.</param>
        /// <returns>True se os bombeiros são iguais, False caso contrário.</returns>
        public override bool Equals(object? obj)
        {
            if (obj == null || !(obj is BombeiroVoluntario))
            {
                return false;
            }

            BombeiroVoluntario aux = (BombeiroVoluntario)obj;
            if (id == aux.id && System.String.Equals(nome, aux.nome) && idade == aux.idade && numerovoluntario == aux.numerovoluntario && contacto == aux.contacto)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Obtém um código hash único para o bombeiro.
        /// </summary>
        /// <returns>Código hash.</returns>
        public override int GetHashCode()
        {
            return id.GetHashCode();
        }
        #endregion

        #region OtherMethods
        #endregion

        #endregion
    }

    [Serializable]
    /// <summary>
    /// Classe que representa um bombeiro privativo, derivada da classe Bombeiro.
    /// </summary>
    public class BombeiroPrivativo : Bombeiro
    {
        #region Attributes

        /// <summary>
        /// Nome da empresa associada ao bombeiro privativo.
        /// </summary>
        private string empresa;

        #endregion

        #region Methods

        #region Constructors
        /// <summary>
        /// Construtor padrão que inicializa o nome da empresa como vazio.
        /// </summary>
        public BombeiroPrivativo()
        {
            id = 0;
            nome = "";
            idade = 0;
            empresa = "";
            contacto = 0;
        }

        /// <summary>
        /// Construtor que permite a inicialização dos atributos com valores específicos.
        /// </summary>
        /// <param name="id">Identificação única do bombeiro.</param>
        /// <param name="nome">Nome do bombeiro.</param>
        /// <param name="idade">Idade do bombeiro.</param>
        /// <param name="emp">Nome da empresa associada ao bombeiro privativo.</param>
        /// <param name="contacto">Número de contacto do bombeiro.</param>
        public BombeiroPrivativo(int id, string nome, int idade, string emp, int contacto)
        {
            this.id = id;
            this.nome = nome;
            this.idade = idade;
            empresa = emp;
            this.contacto = contacto;
        }

        #endregion

        #region Properties
        /// <summary>
        /// Propriedade para aceder ou modificar o nome da empresa associada ao bombeiro privativo.
        /// </summary>
        public string Empresa
        {
            set { empresa = value; }
            get { return empresa; }
        }
        #endregion

        #region Overrides
        /// <summary>
        /// Obtém uma representação de string do objeto Bombeiro Privativo.
        /// </summary>
        /// <returns>String formatada representando as informações do bombeiro Privativo.</returns>
        public override string ToString()
        {
            return String.Format("Ficha Bombeiro Privativo =>ID: {0} | Nome: {1} | Idade: {2} | Nome da Empresa: {3} | Contacto: {4}\n", Id, Nome, Idade, Empresa, Contacto);
        }

        /// <summary>
        /// Verifica se dois bombeiros são iguais, comparando os seus atributos.
        /// </summary>
        /// <param name="obj">Objeto a ser comparado.</param>
        /// <returns>True se os bombeiros são iguais, False caso contrário.</returns>
        public override bool Equals(object? obj)
        {
            if (obj == null || !(obj is BombeiroPrivativo))
            {
                return false;
            }

            BombeiroPrivativo aux = (BombeiroPrivativo)obj;
            if (id == aux.id && System.String.Equals(nome, aux.nome) && idade == aux.idade && empresa == aux.empresa && contacto == aux.contacto)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Obtém um código hash único para o bombeiro.
        /// </summary>
        /// <returns>Código hash.</returns>
        public override int GetHashCode()
        {
            return id.GetHashCode();
        }
        #endregion

        #region OtherMethods
        #endregion

        #endregion
    }
}
