﻿/*
    Trabalho Pratico

    Programação Orientada a Objetos (POO)

    João Lima | 2ºANO | LEIM

 */

/// <summary>
/// Enumeração que representa diferentes tipos de desastres para ocorrências.
/// </summary>
public enum TipoDesastre
{
    Incendio,  //Incendio Florestal
    Sismo,   //Sismo
    Nevao,  //Nevao
    Inundacao   //Inundacao/Enchentes
}

namespace ObjetosNegocio
{
    [Serializable]
    /// <summary>
    /// Classe que representa uma ocorrência.
    /// Implementa a interface IComparable para permitir comparação entre ocorrências.
    /// </summary>
    public class Ocorrencia : IComparable
    {
        #region Attributes

        /// <summary>
        /// Identificação única da ocorrência.
        /// Tipo de desastre associado à ocorrência.
        /// Localização da ocorrência.
        /// Data da ocorrência.
        /// Estado atual da ocorrência (ativo ou inativo).
        /// Nível de gravidade da ocorrência.
        /// </summary>
        private int id;
        private TipoDesastre tipo;
        private DateTime dataocorrencia;
        private string localizacao;
        private bool estado;
        private int nivel;

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor padrão que inicializa os atributos com valores padrão.
        /// </summary>
        public Ocorrencia()
        {
            id = 0;
            tipo = TipoDesastre.Incendio;
            dataocorrencia = DateTime.Today;
            localizacao = "";
            estado = false;
            nivel = 0;
        }

        /// <summary>
        /// Construtor que permite a inicialização dos atributos com valores específicos.
        /// </summary>
        /// <param name="id">Identificação única da ocorrência.</param>
        /// <param name="tipo">Tipo de desastre associado à ocorrência.</param>
        /// <param name="localizacao">Localização da ocorrência.</param>
        /// <param name="estado">Estado atual da ocorrência (ativo ou inativo).</param>
        /// <param name="nivel">Nível de gravidade da ocorrência.</param>
        public Ocorrencia(int id, TipoDesastre tipo, string localizacao, bool estado, int nivel)
        {
            this.id = id;
            this.tipo = tipo;
            dataocorrencia = DateTime.Today;
            this.localizacao = localizacao;
            this.estado = estado;
            this.nivel = nivel;
        }

        /// <summary>
        /// Construtor que permite a inicialização dos atributos com valores específicos, incluindo a data da ocorrência.
        /// </summary>
        /// <param name="id">Identificação única da ocorrência.</param>
        /// <param name="tipo">Tipo de desastre associado à ocorrência.</param>
        /// <param name="data">Data da ocorrência.</param>
        /// <param name="localizacao">Localização da ocorrência.</param>
        /// <param name="estado">Estado atual da ocorrência (ativo ou inativo).</param>
        /// <param name="nivel">Nível de gravidade da ocorrência.</param>
        public Ocorrencia(int id, TipoDesastre tipo, DateTime data, string localizacao, bool estado, int nivel)
        {
            this.id = id;
            this.tipo = tipo;
            dataocorrencia = data;
            this.localizacao = localizacao;
            this.estado = estado;
            this.nivel = nivel;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Propriedade para aceder ou modificar a identificação única da ocorrência.
        /// </summary>
        public int Id
        {
            set { id = value; }
            get { return id; }
        }

        /// <summary>
        /// Propriedade para aceder ou modificar o tipo de desastre associado à ocorrência.
        /// </summary>
        public TipoDesastre Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        /// <summary>
        /// Propriedade para aceder ou modificar a data da ocorrência.
        /// </summary>
        public DateTime Data
        {
            get { return dataocorrencia; }  // Método de leitura
            set { dataocorrencia = value; } // Método de escrita
        }

        /// <summary>
        /// Propriedade para aceder ou modificar a localização da ocorrência.
        /// </summary>
        public string Localizacao
        {
            set { localizacao = value; }
            get { return localizacao; }
        }

        /// <summary>
        /// Propriedade para aceder ou modificar o estado atual da ocorrência (ativo ou inativo).
        /// </summary>
        public bool Estado
        {
            set { estado = value; }
            get { return estado; }
        }

        /// <summary>
        /// Propriedade para aceder ou modificar o nível de gravidade da ocorrência.
        /// </summary>
        public int Nivel
        {
            set { nivel = value; }
            get { return nivel; }
        }

        #endregion


        #region Overrides

        /// <summary>
        /// Obtém uma representação de string da ocorrência.
        /// </summary>
        /// <returns>String formatada representando a ocorrência.</returns>
        public override string ToString()
        {
            return String.Format("Ficha de Ocorrencia =>ID: {0} | Tipo: {1} | Data: {2} | Localizacao: {3} | Estado: {4} | Nivel: {5}\n", Id, Tipo, Data, Localizacao, Estado, Nivel);
        }

        /// <summary>
        /// Verifica se duas ocorrências são iguais, comparando os seus atributos.
        /// </summary>
        /// <param name="obj">Objeto a ser comparado.</param>
        /// <returns>True se as ocorrências são iguais, False caso contrário.</returns>
        public override bool Equals(object? obj)
        {
            if (obj == null || !(obj is Ocorrencia))
            {
                return false;
            }

            Ocorrencia aux = (Ocorrencia)obj;
            if (id == aux.id && tipo == aux.tipo && dataocorrencia == aux.dataocorrencia && System.String.Equals(localizacao, aux.localizacao) && estado == aux.estado)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Obtém um código hash único para a ocorrência.
        /// </summary>
        /// <returns>Código hash.</returns>
        public override int GetHashCode()
        {
            return id.GetHashCode(); // Ou qualquer outra lógica para gerar um código hash único para a instância
        }
        #endregion

        #region OtherMethods

        /// <summary>
        /// Método de comparação utilizado para ordenar ocorrências por localização.
        /// </summary>
        /// <param name="obj">Objeto a ser comparado.</param>
        /// <returns>Resultado da comparação.</returns>
        public int CompareTo(object? obj)
        {
            if (obj is Ocorrencia aux)
            {
                // Verifica se either this.localizacao ou aux.localizacao são nulos
                if (this.localizacao != null && aux.localizacao != null)
                {
                    return this.localizacao.CompareTo(aux.localizacao);
                }
                // Trate o caso em que uma ou ambas as localizações são nulas
                else if (this.localizacao == null && aux.localizacao != null)
                {
                    return -1; // Ou outra lógica dependendo do seu caso
                }
                else if (this.localizacao != null && aux.localizacao == null)
                {
                    return 1; // Ou outra lógica dependendo do seu caso
                }
                else
                {
                    return 0; // Ambas são nulas
                }
            }
            else
            {
                throw new ArgumentException("O objeto fornecido não é uma instância de Ocorrencia", nameof(obj));
            }
        }
        #endregion
        #endregion
    }
}