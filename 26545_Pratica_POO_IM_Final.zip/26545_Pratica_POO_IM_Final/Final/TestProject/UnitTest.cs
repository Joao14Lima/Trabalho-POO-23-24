/*
    Trabalho Pratico

    Programa��o Orientada a Objetos (POO)

    Jo�o Lima | 2�ANO | LEIM

 */

using ObjetosNegocio;
using RegrasDeNegocio;

namespace TestProject
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            /// <summary>
            /// Testa a inser��o de uma ocorr�ncia com dados v�lidos.
            /// </summary>
            [TestMethod]
            void TesteInsereOcorrenciaDadosValidos()
            {
                // Arrange
                int id = 1;
                Ocorrencia OcValida = new Ocorrencia
                {
                    //Dados validos
                    Localizacao = "Braga",
                    Nivel = 1
                };

                // Act e Assert
                Assert.ThrowsException<Exception>(() => GereQuartel.InsereOcorrencia(id, OcValida));
            }

            /// <summary>
            /// Testa a inser��o de uma ocorr�ncia com dados inv�lidos.
            /// </summary>
            [TestMethod]
            void TesteInsereOcorrenciaDadosInvalidos()
            {
                // Arrange
                int id = 1;
                Ocorrencia OcInvalida = new Ocorrencia
                {
                    // Dados invalidos
                    Localizacao = "Braga",
                    Nivel = 0
                };
                Assert.ThrowsException<Exception>(() => GereQuartel.InsereOcorrencia(id, OcInvalida));
            }

            /// <summary>
            /// Testa a inser��o de um bombeiro com dados v�lidos.
            /// </summary>
            [TestMethod]
            void TesteInsereBombeiroDadosValidos()
            {
                // Arrange
                int id = 1;
                Bombeiro bValido = new Bombeiro
                {
                    // Dados validos
                    Idade = 25,
                    Contacto = 912345678
                };
                bool resultado = GereQuartel.InsereBombeiro(id, bValido);

                Assert.IsTrue(resultado);
            }

            /// <summary>
            /// Testa a inser��o de um bombeiro com dados inv�lidos.
            /// </summary>
            [TestMethod]
            void TesteInsereBombeiroDadosInvalidos()
            {
                // Arrange
                int id = 1;
                Bombeiro bInvalido = new Bombeiro
                {
                    // Dados inv�lidos
                    Idade = 17,
                    Contacto = 123456789
                };

                Assert.ThrowsException<Exception>(() => GereQuartel.InsereBombeiro(id, bInvalido));
            }
        }
    }
}