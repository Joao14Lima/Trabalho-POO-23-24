﻿/*
    Trabalho Pratico

    Programação Orientada a Objetos (POO)

    João Lima | 2ºANO | LEIM

 */

using ObjetosNegocio;
using RegrasDeNegocio;

namespace Final
{
    class FrontEnd
    {
        static void Main(string[] args)
        {

            #region Ocorrencias
            bool f;

            Ocorrencia o1 = new Ocorrencia(1, TipoDesastre.Inundacao, DateTime.Now.AddDays(1), "Apulia", true, 1);

            f = GereQuartel.InsereOcorrenciaSemId(o1);

            if (f == true)
            {
                Console.WriteLine("\nOcorrencia Inserida com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro!");
            }

            Ocorrencia o2 = new Ocorrencia(2, TipoDesastre.Nevao, DateTime.Now.AddDays(4), "Braga", true, 3);
            Ocorrencia o3 = new Ocorrencia(3, TipoDesastre.Sismo, DateTime.Now.AddDays(3), "Barcelos", true, 2);

            #region Remove Ocorrencia

            if (GereQuartel.RemoveOcorrencia(1, o1))
            {
                Console.WriteLine("Ocorrencia removida com sucesso!");
            }
            else
            {
                Console.WriteLine("A Ocorrência não existe!\n");
            }
            #endregion

            #region Insere Ocorrencias
            if (f == true)
            {
                Console.WriteLine("Lido com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro na Leitura!");
            }

            Ocorrencia oc1 = new Ocorrencia(1, TipoDesastre.Inundacao, DateTime.Now.AddDays(1), "Apulia", true, 1);
            Ocorrencia oc2 = new Ocorrencia(2, TipoDesastre.Nevao, DateTime.Now.AddDays(4), "Braga", true, 3);
            Ocorrencia oc3 = new Ocorrencia(3, TipoDesastre.Sismo, DateTime.Now.AddDays(3), "Barcelos", true, 2);
            GereQuartel.InsereOcorrencia(o1.Id, oc1);
            GereQuartel.InsereOcorrencia(o2.Id, oc2);

            f = GereQuartel.InsereOcorrencia(o3.Id, oc3);

            if (f == true)
            {
                Console.WriteLine("Ocorrencia Registada com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro ao Registar");
            }
            #endregion

            #region Salva Ocorrencias
            bool so = GereQuartel.SalvaOcorrencia("C:\\Users\\Win11\\Desktop\\26545_Pratica_POO_IM_Final\\ocorrencia.bin");

            if (so)
            {
                Console.WriteLine("\nOcorrências Salvas com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro ao Salvar Ocorrências!");
            }
            #endregion

            GereQuartel.MostraTodasAsOcorrencias();
            #endregion

            #region Bombeiros
            bool e;

            Bombeiro b1 = new Bombeiro(1, "Joao", 19, 932532987);

            e = GereQuartel.InsereBombeiroSemId(b1);

            if (e == true)
            {
                Console.WriteLine("\nBombeiro Inserido com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro!");
            }

            Bombeiro b2 = new Bombeiro(2, "Laura", 20, 986572875);
            Bombeiro b3 = new Bombeiro(3, "Luis", 25, 986523456);

            #region Remove Bombeiros

            if (GereQuartel.RemoveBombeiro(1, b1))
            {
                Console.WriteLine("Bombeiro removido com sucesso!");
            }
            else
            {
                Console.WriteLine("O Bombeiro não existe!\n");
            }
            #endregion

            #region Insere Bombeiros
            if (e == true)
            {
                Console.WriteLine("Lido com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro na Leitura!");
            }

            Bombeiro bo1 = new Bombeiro(1, "Joao", 19, 932532987);
            Bombeiro bo2 = new Bombeiro(2, "Laura", 20, 986572875);
            Bombeiro bo3 = new Bombeiro(3, "Luis", 25, 986523456);
            GereQuartel.InsereBombeiro(b1.Id, bo1);
            GereQuartel.InsereBombeiro(b2.Id, bo2);
            e = GereQuartel.InsereBombeiro(b3.Id, bo3);

            if (e == true)
            {
                Console.WriteLine("Bombeiro Registado com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro ao Registar");
            }
            #endregion

            #region Salva Bombeiros
            bool sb = GereQuartel.SalvaBombeiro("C:\\Users\\Win11\\Desktop\\26545_Pratica_POO_IM_Final\\bombeiros.bin");

            if (sb)
            {
                Console.WriteLine("\nBombeiros Salvos com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro ao Salvar Bombeiros!");
            }
            #endregion

            GereQuartel.MostraTodosOsBombeiros();
            #endregion

            #region Bombeiros Profissionais
            bool ep;

            BombeiroProfissional bp1 = new BombeiroProfissional(1, "Joao", 19, TipoEspecializacao.Mergulhador, 970993201);

            ep = GereQuartel.InsereBombeiroProfissionalSemId(bp1);

            if (ep == true)
            {
                Console.WriteLine("\nBombeiro Profissional Inserido com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro!");
            }

            BombeiroProfissional bp2 = new BombeiroProfissional(2, "Carolina", 22, TipoEspecializacao.TecnicoDeInformática, 933185371);
            BombeiroProfissional bp3 = new BombeiroProfissional(3, "Tiago", 25, TipoEspecializacao.Motorista, 953071622);

            #region Remove Bombeiro Profissional

            if (GereQuartel.RemoveBombeiroProfissional(1, bp1))
            {
                Console.WriteLine("Bombeiro Profissional removido com sucesso!");
            }
            else
            {
                Console.WriteLine("O Bombeiro Profissional não existe!\n");
            }
            #endregion

            #region Insere Bombeiros Profissionais
            if (ep == true)
            {
                Console.WriteLine("Lido com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro na Leitura!");
            }

            BombeiroProfissional bop1 = new BombeiroProfissional(1, "Joao", 19, TipoEspecializacao.TecnicoDeInformática, 970993201);
            BombeiroProfissional bop2 = new BombeiroProfissional(2, "Carolina", 22, TipoEspecializacao.TecnicoDeInformática, 933185371);
            BombeiroProfissional bop3 = new BombeiroProfissional(3, "Tiago", 25, TipoEspecializacao.Motorista, 953071622);
            GereQuartel.InsereBombeiroProfissional(bp1.Id, bop1);
            GereQuartel.InsereBombeiroProfissional(bp2.Id, bop2);
            ep = GereQuartel.InsereBombeiroProfissional(bp3.Id, bop3);

            if (ep == true)
            {
                Console.WriteLine("Bombeiro Profissional Registado com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro ao Registar");
            }
            #endregion

            #region Salva Bombeiros Profissionais
            bool sbp = GereQuartel.SalvaBombeiroProfissional("C:\\Users\\Win11\\Desktop\\26545_Pratica_POO_IM_Final\\bombeirosprofissionais.bin");

            if (sbp)
            {
                Console.WriteLine("\nBombeiros Profissionais Salvos com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro ao Salvar Bombeiros Profissionais!");
            }
            #endregion

            GereQuartel.MostraTodosOsBombeirosProfissionais();
            #endregion

            #region Bombeiros Voluntarios
            bool ev;

            BombeiroVoluntario bv1 = new BombeiroVoluntario(1, "Alice", 19, 23, 957178786);

            ev = GereQuartel.InsereBombeiroVoluntarioSemId(bv1);

            if (ev == true)
            {
                Console.WriteLine("\nBombeiro Voluntario Inserido com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro!");
            }

            BombeiroVoluntario bv2 = new BombeiroVoluntario(2, "Rodrigo", 20, 31, 938808005);
            BombeiroVoluntario bv3 = new BombeiroVoluntario(3, "Rafaela", 25, 16, 991502631);

            #region Remove Bombeiro Voluntario

            if (GereQuartel.RemoveBombeiroVoluntario(1, bv1))
            {
                Console.WriteLine("Bombeiro Voluntario removido com sucesso!");
            }
            else
            {
                Console.WriteLine("O Bombeiro Voluntario não existe!\n");
            }
            #endregion

            #region Insere Bombeiros Voluntarios
            if (ev == true)
            {
                Console.WriteLine("Lido com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro na Leitura!");
            }

            BombeiroVoluntario bov1 = new BombeiroVoluntario(1, "Alice", 19, 23, 957178786);
            BombeiroVoluntario bov2 = new BombeiroVoluntario(2, "Rodrigo", 20, 31, 938808005);
            BombeiroVoluntario bov3 = new BombeiroVoluntario(3, "Rafaela", 25, 16, 991502631);
            GereQuartel.InsereBombeiroVoluntario(bv1.Id, bov1);
            GereQuartel.InsereBombeiroVoluntario(bv2.Id, bov2);
            ev = GereQuartel.InsereBombeiroVoluntario(bv3.Id, bov3);

            if (ev == true)
            {
                Console.WriteLine("Bombeiro Voluntario Registado com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro ao Registar!");
            }
            #endregion

            #region Salva Bombeiros Voluntarios
            bool sbv = GereQuartel.SalvaBombeiroVoluntario("C:\\Users\\Win11\\Desktop\\26545_Pratica_POO_IM_Final\\bombeirosvoluntarios.bin");

            if (sbv)
            {
                Console.WriteLine("\nBombeiros Voluntarios Salvos com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro ao Salvar Bombeiros Voluntarios!");
            }
            #endregion

            GereQuartel.MostraTodosOsBombeirosVoluntarios();
            #endregion

            #region Bombeiros Privativos
            bool epv;

            BombeiroPrivativo bpv1 = new BombeiroPrivativo(1, "Gustavo", 26, "Federação Dos Bombeiros Do Distrito De Braga", 905262309);

            epv = GereQuartel.InsereBombeiroPrivativoSemId(bpv1);

            if (epv == true)
            {
                Console.WriteLine("\nBombeiro Privativo Inserido com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro!");
            }

            BombeiroPrivativo bpv2 = new BombeiroPrivativo(2, "Matilde ", 22, "Associação Humanitária Dos Bombeiros Voluntários De Viatodos", 990661836);
            BombeiroPrivativo bpv3 = new BombeiroPrivativo(3, "Antonio", 30, "Associação Humanitária De Bombeiros Voluntários De Barcelos", 948198132);

            #region Remove Bombeiros Privativo

            if (GereQuartel.RemoveBombeiroPrivativo(1, bpv1))
            {
                Console.WriteLine("Bombeiro Privativo removido com sucesso!");
            }
            else
            {
                Console.WriteLine("O Bombeiro Privativo não existe!\n");
            }
            #endregion

            #region Insere Bombeiros Privativos
            if (epv == true)
            {
                Console.WriteLine("Lido com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro na Leitura!");
            }

            BombeiroPrivativo bopv1 = new BombeiroPrivativo(1, "Gustavo", 26, "Federação Dos Bombeiros Do Distrito De Braga", 905262309);
            BombeiroPrivativo bopv2 = new BombeiroPrivativo(2, "Matilde", 22, "Associação Humanitária Dos Bombeiros Voluntários De Viatodos", 990661836);
            BombeiroPrivativo bopv3 = new BombeiroPrivativo(3, "Antonio", 30, "Associação Humanitária De Bombeiros Voluntários De Barcelos", 948198132);
            GereQuartel.InsereBombeiroPrivativo(bpv1.Id, bopv1);
            GereQuartel.InsereBombeiroPrivativo(bpv2.Id, bopv2);
            epv = GereQuartel.InsereBombeiroPrivativo(bpv3.Id, bopv3);

            if (epv == true)
            {
                Console.WriteLine("Bombeiro Privativo Registado com Sucesso!");
            }
            else
            {
                Console.WriteLine("Erro ao Registar!");
            }
            #endregion

            #region Salva Bombeiros Privativos
            bool sbpv = GereQuartel.SalvaBombeiroPrivativo("C:\\Users\\Win11\\Desktop\\26545_Pratica_POO_IM_Final\\bombeirosprivativos.bin");

            if (sbpv)
            {
                Console.WriteLine("\nBombeiros Privativos Salvos com Sucesso!");
            }
            else
            {
                Console.WriteLine("\nErro ao Salvar Bombeiros Privativos!");
            }
            #endregion

            GereQuartel.MostraTodosOsBombeirosPrivativos();
            #endregion

        }
    }
}