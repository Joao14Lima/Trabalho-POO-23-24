﻿/*
    Trabalho Pratico

    Programação Orientada a Objetos (POO)

    João Lima | 2ºANO | LEIM

 */

using ObjetosNegocio;

namespace Dados
{
    [Serializable]
    /// <summary>
    /// Classe responsável por operações relacionadas a colaboradores, neste caso, bombeiros.
    /// </summary>
    public class Colaboradores
    {

        #region Attributes
        /// <summary>
        /// Dicionário estático para armazenar bombeiros, onde a chave é um identificador (int) e o valor é uma instância de Bombeiro.
        /// </summary>
        private static Dictionary<int, Bombeiro> bombeiros;

        private static Dictionary<int, Bombeiro> clonebombeiros;

        /// <summary>
        /// Dicionário estático para armazenar bombeiros profissionais, onde a chave é um identificador (int) e o valor é uma instância de Bombeiro.
        /// </summary>
        private static Dictionary<int, BombeiroProfissional> bombeiroprof;

        private static Dictionary<int, BombeiroProfissional> clonebombeiroprof;

        /// <summary>
        /// Dicionário estático para armazenar bombeiros profissionais, onde a chave é um identificador (int) e o valor é uma instância de Bombeiro.
        /// </summary>
        private static Dictionary<int, BombeiroVoluntario> bombeirovolunt;

        private static Dictionary<int, BombeiroVoluntario> clonebombeirovolunt;

        /// <summary>
        /// Dicionário estático para armazenar bombeiros profissionais, onde a chave é um identificador (int) e o valor é uma instância de Bombeiro.
        /// </summary>
        private static Dictionary<int, BombeiroPrivativo> bombeiropriva;

        private static Dictionary<int, BombeiroPrivativo> clonebombeiropriva;

        #endregion

        #region Constructors
        /// <summary>
        /// Classe Colaboradores que gerencia diferentes tipos de bombeiros.
        /// </summary>
        static Colaboradores()
        {
            bombeiros = new Dictionary<int, Bombeiro>();
            clonebombeiros = new Dictionary<int, Bombeiro>();

            bombeiroprof = new Dictionary<int, BombeiroProfissional>();
            clonebombeiroprof = new Dictionary<int, BombeiroProfissional>();

            bombeirovolunt = new Dictionary<int, BombeiroVoluntario>();
            clonebombeirovolunt = new Dictionary<int, BombeiroVoluntario>();

            bombeiropriva = new Dictionary<int, BombeiroPrivativo>();
            clonebombeiropriva = new Dictionary<int, BombeiroPrivativo>();
        }
        #endregion

        #region Bombeiro
        #region Methods
        /// <summary>
        /// Insere ou atualiza um bombeiro no dicionário de bombeiros.
        /// </summary>
        /// <param name="id">Identificador do bombeiro.</param>
        /// <param name="b">Instância de Bombeiro a ser inserida ou atualizada.</param>
        /// <returns>True se o bombeiro foi inserido ou atualizado; False se o bombeiro já existe e é igual ao novo bombeiro.</returns>
        public static bool InsereBombeiro(int id, Bombeiro b)
        {
            if (!bombeiros.ContainsKey(id))
            {
                bombeiros.Add(id, b);
                return true;
            }

            if (!bombeiros[id].Equals(b))
            {
                bombeiros[id] = b;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Insere um bombeiro sem ID na coleção, se o ID ainda não estiver presente.
        /// </summary>
        /// <param name="b">O objeto Bombeiro a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a inserção for bem-sucedida, falso se o ID já existir.</returns>
        public static bool InsereBombeiroSemId(Bombeiro b)
        {
            if (!bombeiros.ContainsKey(b.Id))
            {
                bombeiros.Add(b.Id, b);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Verifica se um bombeiro com o identificador especificado existe e é igual ao bombeiro fornecido.
        /// </summary>
        /// <param name="id">Identificador do bombeiro a ser verificado.</param>
        /// <param name="b">Instância de Bombeiro a ser comparada.</param>
        /// <returns>True se o bombeiro existe e é igual ao bombeiro fornecido; False se o bombeiro não existe.</returns>
        public static bool ExisteBombeiro(int id, Bombeiro b)
        {
            if (bombeiros.ContainsKey(id))
            {
                return bombeiros[id].Equals(b);
            }

            throw new Exception("O Bombeiro não existe");
        }

        /// <summary>
        /// Remove um bombeiro do registo, com base no seu identificador único.
        /// </summary>
        /// <param name="id">O identificador único do bombeiro a ser removido.</param>
        /// <param name="b">O objeto Bombeiro a ser comparado para garantir a remoção correta.</param>
        /// <returns>Verdadeiro se o bombeiro foi removido com sucesso; falso caso contrário.</returns>
        public static bool RemoveBombeiro(int id, Bombeiro b)
        {

            if (bombeiros.ContainsKey(id))
            {
                if ((bombeiros[id].Equals(b)))
                {
                    bombeiros.Remove(id);
                    return true;
                }

            }
            return false;
        }

        /// <summary>
        /// Método para salvar informações de bombeiros em um arquivo binário.
        /// </summary>
        /// <param name="fileName">O nome do arquivo no qual as informações serão salvas.</param>
        /// <returns>Retorna verdadeiro se a operação for bem-sucedida e falso em caso de falha.</returns>
        public static bool SalvaBombeiro(string fileName)
        {
            try
            {
                using (FileStream fileStream = new FileStream(fileName, FileMode.Create))
                using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
                {
                    foreach (var bombeiro in bombeiros.Values)
                    {
                        binaryWriter.Write(bombeiro.Id);
                        binaryWriter.Write(bombeiro.Nome);
                        binaryWriter.Write(bombeiro.Idade);
                        binaryWriter.Write(bombeiro.Contacto);
                    }
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Método estático responsável por criar e devolver um clone do dicionário de Bombeiros existente.
        /// </summary>
        /// <returns>Um novo dicionário que é um clone do dicionário original de Bombeiros.</returns>
        public static Dictionary<int, List<Bombeiro>> CloneDictionaryBombeiros()
        {
            Dictionary<int, List<Bombeiro>> clonebombeiros = bombeiros
                .ToDictionary(entry => entry.Key, entry => new List<Bombeiro> { entry.Value });

            return clonebombeiros;
        }

        /// <summary>
        /// Método estático responsável por mostrar no console as informações contidas no dicionário de Bombeiros.
        /// </summary>
        public static void ShowDictinaryBombeiros()
        {
            Dictionary<int, List<Bombeiro>> clonebombeiros = Colaboradores.CloneDictionaryBombeiros();

            foreach (KeyValuePair<int, List<Bombeiro>> entry in clonebombeiros)
            {
                Console.WriteLine($"ID: {entry.Key}");

                foreach (Bombeiro bombeiros in entry.Value)
                {
                    Console.WriteLine(bombeiros.ToString());
                }
            }
        }
        #endregion
        #endregion

        #region Bombeiro Profissional
        #region Methods
        /// <summary>
        /// Insere um bombeiro profissional na coleção se o ID ainda não existir. Se o ID já existir,
        /// atualiza os dados do bombeiro profissional se forem diferentes.
        /// </summary>
        /// <param name="id">ID do bombeiro profissional a ser inserido ou atualizado.</param>
        /// <param name="bp">Instância do bombeiro profissional a ser inserido ou atualizado.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção ou atualização for bem-sucedida, falso se não for.</returns>
        public static bool InsereBombeiroProfissional(int id, BombeiroProfissional bp)
        {
            if (!bombeiroprof.ContainsKey(id))
            {
                bombeiroprof.Add(id, bp);
                return true;
            }

            if (!bombeiroprof[id].Equals(bp))
            {
                bombeiroprof[id] = bp;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Insere um bombeiro profissional na coleção se o ID ainda não existir.
        /// </summary>
        /// <param name="bp">Instância do bombeiro profissional a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        public static bool InsereBombeiroProfissionalSemId(BombeiroProfissional bp)
        {
            if (!bombeiroprof.ContainsKey(bp.Id))
            {
                bombeiroprof.Add(bp.Id, bp);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Verifica se um bombeiro profissional com o ID fornecido existe e se é igual à instância fornecida.
        /// </summary>
        /// <param name="id">ID do bombeiro profissional a ser verificado.</param>
        /// <param name="bp">Instância do bombeiro profissional a ser comparada.</param>
        /// <returns>Retorna verdadeiro se o bombeiro profissional com o ID fornecido existe e é igual à instância fornecida.</returns>
        /// <exception cref="Exception">Lança uma exceção se o bombeiro profissional não existir.</exception>
        public static bool ExisteBombeiroProfissional(int id, BombeiroProfissional bp)
        {
            if (bombeiroprof.ContainsKey(id))
            {
                return bombeiroprof[id].Equals(bp);
            }

            throw new Exception("O Bombeiro Profissional não existe");
        }

        /// <summary>
        /// Remove um bombeiro profissional da coleção se o ID e os dados fornecidos coincidirem.
        /// </summary>
        /// <param name="id">ID do bombeiro profissional a ser removido.</param>
        /// <param name="bp">Instância do bombeiro profissional a ser comparada para remoção.</param>
        /// <returns>Retorna verdadeiro se a operação de remoção for bem-sucedida, falso se não for.</returns>
        public static bool RemoveBombeiroProfissional(int id, BombeiroProfissional bp)
        {

            if (bombeiroprof.ContainsKey(id))
            {
                if ((bombeiroprof[id].Equals(bp)))
                {
                    bombeiroprof.Remove(id);
                    return true;
                }

            }
            return false;
        }

        /// <summary>
        /// Salva os dados dos bombeiros profissionais em um arquivo binário.
        /// </summary>
        /// <param name="fileName">Nome do arquivo para salvar os dados dos bombeiros profissionais.</param>
        /// <returns>Retorna verdadeiro se a operação de salvamento for bem-sucedida, falso se não for.</returns>
        public static bool SalvaBombeiroProfissional(string fileName)
        {
            try
            {
                using (FileStream fileStream = new FileStream(fileName, FileMode.Create))
                using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
                {
                    foreach (var bombeiroprofissional in bombeiroprof.Values)
                    {
                        binaryWriter.Write(bombeiroprofissional.Id);
                        binaryWriter.Write(bombeiroprofissional.Nome);
                        binaryWriter.Write(bombeiroprofissional.Idade);
                        binaryWriter.Write((int)bombeiroprofissional.Tipoesp);
                        binaryWriter.Write(bombeiroprofissional.Contacto);

                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Método estático responsável por criar e devolver um clone do dicionário de Bombeiros Profissionais existente.
        /// </summary>
        /// <returns>Um novo dicionário que é um clone do dicionário original de Bombeiros Profissionais.</returns>
        public static Dictionary<int, List<BombeiroProfissional>> CloneDictionaryBombeirosProfissional()
        {
            Dictionary<int, List<BombeiroProfissional>> clonebombeiroprof = bombeiroprof
                .ToDictionary(entry => entry.Key, entry => new List<BombeiroProfissional> { entry.Value });

            return clonebombeiroprof;
        }

        /// <summary>
        /// Método estático responsável por mostrar no console as informações contidas no dicionário de Bombeiros Profissionais.
        /// </summary>
        public static void ShowDictinaryBombeiroProfissional()
        {
            Dictionary<int, List<BombeiroProfissional>> clonebombeiroprof = Colaboradores.CloneDictionaryBombeirosProfissional();

            foreach (KeyValuePair<int, List<BombeiroProfissional>> entry in clonebombeiroprof)
            {
                Console.WriteLine($"ID: {entry.Key}");

                foreach (BombeiroProfissional bombeiroprof in entry.Value)
                {
                    Console.WriteLine(bombeiroprof.ToString());
                }
            }
        }
        #endregion
        #endregion

        #region Bombeiro Voluntario
        #region Methods
        /// <summary>
        /// Insere um bombeiro voluntário na coleção se o ID ainda não existir. Se o ID já existir,
        /// atualiza os dados do bombeiro voluntário se forem diferentes.
        /// </summary>
        /// <param name="id">ID do bombeiro voluntário a ser inserido ou atualizado.</param>
        /// <param name="bv">Instância do bombeiro voluntário a ser inserido ou atualizado.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção ou atualização for bem-sucedida, falso se não for.</returns>
        public static bool InsereBombeiroVoluntario(int id, BombeiroVoluntario bv)
        {
            if (!bombeirovolunt.ContainsKey(id))
            {
                bombeirovolunt.Add(id, bv);
                return true;
            }

            if (!bombeirovolunt[id].Equals(bv))
            {
                bombeirovolunt[id] = bv;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Insere um bombeiro voluntário na coleção se o ID ainda não existir.
        /// </summary>
        /// <param name="bv">Instância do bombeiro voluntário a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        public static bool InsereBombeiroVoluntarioSemId(BombeiroVoluntario bv)
        {
            if (!bombeirovolunt.ContainsKey(bv.Id))
            {
                bombeirovolunt.Add(bv.Id, bv);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Verifica se um bombeiro voluntário com o ID fornecido existe e se é igual à instância fornecida.
        /// </summary>
        /// <param name="id">ID do bombeiro voluntário a ser verificado.</param>
        /// <param name="bv">Instância do bombeiro voluntário a ser comparada.</param>
        /// <returns>Retorna verdadeiro se o bombeiro voluntário com o ID fornecido existe e é igual à instância fornecida.</returns>
        /// <exception cref="Exception">Lança uma exceção se o bombeiro voluntário não existir.</exception>
        public static bool ExisteBombeiroVoluntario(int id, BombeiroVoluntario bv)
        {
            if (bombeirovolunt.ContainsKey(id))
            {
                return bombeirovolunt[id].Equals(bv);
            }

            throw new Exception("O Bombeiro Voluntario não existe");
        }

        /// <summary>
        /// Remove um bombeiro voluntário da coleção se o ID e os dados fornecidos coincidirem.
        /// </summary>
        /// <param name="id">ID do bombeiro voluntário a ser removido.</param>
        /// <param name="bv">Instância do bombeiro voluntário a ser comparada para remoção.</param>
        /// <returns>Retorna verdadeiro se a operação de remoção for bem-sucedida, falso se não for.</returns>
        public static bool RemoveBombeiroVoluntario(int id, BombeiroVoluntario bv)
        {

            if (bombeirovolunt.ContainsKey(id))
            {
                if ((bombeirovolunt[id].Equals(bv)))
                {
                    bombeirovolunt.Remove(id);
                    return true;
                }

            }
            return false;
        }

        /// <summary>
        /// Salva os dados dos bombeiros voluntários em um arquivo binário.
        /// </summary>
        /// <param name="fileName">Nome do arquivo para salvar os dados dos bombeiros voluntários.</param>
        /// <returns>Retorna verdadeiro se a operação de salvamento for bem-sucedida, falso se não for.</returns>
        public static bool SalvaBombeiroVoluntario(string fileName)
        {
            try
            {
                using (FileStream fileStream = new FileStream(fileName, FileMode.Create))
                using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
                {
                    foreach (var bombeirovoluntario in bombeirovolunt.Values)
                    {
                        binaryWriter.Write(bombeirovoluntario.Id);
                        binaryWriter.Write(bombeirovoluntario.Nome);
                        binaryWriter.Write(bombeirovoluntario.Idade);
                        binaryWriter.Write(bombeirovoluntario.NumeroVoluntario);
                        binaryWriter.Write(bombeirovoluntario.Contacto);

                    }
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Método estático responsável por criar e devolver um clone do dicionário de Bombeiros Voluntários existente.
        /// </summary>
        /// <returns>Um novo dicionário que é um clone do dicionário original de Bombeiros Voluntários.</returns>
        public static Dictionary<int, List<BombeiroVoluntario>> CloneDictionaryBombeiroVoluntario()
        {
            Dictionary<int, List<BombeiroVoluntario>> clonebombeirovolunt = bombeirovolunt
                .ToDictionary(entry => entry.Key, entry => new List<BombeiroVoluntario> { entry.Value });

            return clonebombeirovolunt;
        }

        /// <summary>
        /// Método estático responsável por mostrar no console as informações contidas no dicionário de Bombeiros Voluntários.
        /// </summary>
        public static void ShowDictinaryBombeiroVoluntario()
        {
            Dictionary<int, List<BombeiroVoluntario>> clonebombeirovolunt = Colaboradores.CloneDictionaryBombeiroVoluntario();

            foreach (KeyValuePair<int, List<BombeiroVoluntario>> entry in clonebombeirovolunt)
            {
                Console.WriteLine($"ID: {entry.Key}");

                foreach (BombeiroVoluntario bombeirovolunt in entry.Value)
                {
                    Console.WriteLine(bombeirovolunt.ToString());
                }
            }
        }
        #endregion
        #endregion

        #region Bombeiro Privativo
        #region Methods
        /// <summary>
        /// Insere um bombeiro privativo na coleção se o ID ainda não existir. Se o ID já existir,
        /// atualiza os dados do bombeiro privativo se forem diferentes.
        /// </summary>
        /// <param name="id">ID do bombeiro privativo a ser inserido ou atualizado.</param>
        /// <param name="bpv">Instância do bombeiro privativo a ser inserido ou atualizado.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção ou atualização for bem-sucedida, falso se não for.</returns>
        public static bool InsereBombeiroPrivativo(int id, BombeiroPrivativo bpv)
        {
            if (!bombeiropriva.ContainsKey(id))
            {
                bombeiropriva.Add(id, bpv);
                return true;
            }

            if (!bombeiropriva[id].Equals(bpv))
            {
                bombeiropriva[id] = bpv;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Insere um bombeiro privativo na coleção se o ID ainda não existir.
        /// </summary>
        /// <param name="bpv">Instância do bombeiro privativo a ser inserido.</param>
        /// <returns>Retorna verdadeiro se a operação de inserção for bem-sucedida, falso se não for.</returns>
        public static bool InsereBombeiroPrivativoSemId(BombeiroPrivativo bpv)
        {
            if (!bombeiropriva.ContainsKey(bpv.Id))
            {
                bombeiropriva.Add(bpv.Id, bpv);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Verifica se um bombeiro privativo com o ID fornecido existe e se é igual à instância fornecida.
        /// </summary>
        /// <param name="id">ID do bombeiro privativo a ser verificado.</param>
        /// <param name="bpv">Instância do bombeiro privativo a ser comparada.</param>
        /// <returns>Retorna verdadeiro se o bombeiro privativo com o ID fornecido existe e é igual à instância fornecida.</returns>
        /// <exception cref="Exception">Lança uma exceção se o bombeiro privativo não existir.</exception>
        public static bool ExisteBombeiroPrivativo(int id, BombeiroPrivativo bpv)
        {
            if (bombeiropriva.ContainsKey(id))
            {
                return bombeiropriva[id].Equals(bpv);
            }

            throw new Exception("O Bombeiro Voluntario não existe");
        }

        /// <summary>
        /// Remove um bombeiro privativo da coleção se o ID e os dados fornecidos coincidirem.
        /// </summary>
        /// <param name="id">ID do bombeiro privativo a ser removido.</param>
        /// <param name="bpv">Instância do bombeiro privativo a ser comparada para remoção.</param>
        /// <returns>Retorna verdadeiro se a operação de remoção for bem-sucedida, falso se não for.</returns>
        public static bool RemoveBombeiroPrivativo(int id, BombeiroPrivativo bpv)
        {

            if (bombeiropriva.ContainsKey(id))
            {
                if ((bombeiropriva[id].Equals(bpv)))
                {
                    bombeiropriva.Remove(id);
                    return true;
                }

            }
            return false;
        }

        /// <summary>
        /// Método para salvar informações de bombeiros privativos em um arquivo binário.
        /// </summary>
        /// <param name="fileName">O nome do arquivo no qual as informações serão salvas.</param>
        /// <returns>Retorna verdadeiro se a operação for bem-sucedida e falso em caso de falha.</returns>
        public static bool SalvaBombeiroPrivativo(string fileName)
        {
            try
            {
                using (FileStream fileStream = new FileStream(fileName, FileMode.Create))
                using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
                {
                    foreach (var bombeiroprivativo in bombeiropriva.Values)
                    {
                        binaryWriter.Write(bombeiroprivativo.Id);
                        binaryWriter.Write(bombeiroprivativo.Nome);
                        binaryWriter.Write(bombeiroprivativo.Idade);
                        binaryWriter.Write(bombeiroprivativo.Empresa);
                        binaryWriter.Write(bombeiroprivativo.Contacto);

                    }
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Método estático responsável por criar e devolver um clone do dicionário de Bombeiros Privativos existente.
        /// </summary>
        /// <returns>Um novo dicionário que é um clone do dicionário original de Bombeiros Privativos.</returns>
        public static Dictionary<int, List<BombeiroPrivativo>> CloneDictionaryBombeiroPrivativo()
        {
            Dictionary<int, List<BombeiroPrivativo>> clonebombeiropriva = bombeiropriva
                .ToDictionary(entry => entry.Key, entry => new List<BombeiroPrivativo> { entry.Value });

            return clonebombeiropriva;
        }

        /// <summary>
        /// Método estático responsável por mostrar no console as informações contidas no dicionário de Bombeiros Privativos.
        /// </summary>
        public static void ShowDictinaryBombeiroPrivativo()
        {
            Dictionary<int, List<BombeiroPrivativo>> clonebombeiropriva = Colaboradores.CloneDictionaryBombeiroPrivativo();

            foreach (KeyValuePair<int, List<BombeiroPrivativo>> entry in clonebombeiropriva)
            {
                Console.WriteLine($"ID: {entry.Key}");

                foreach (BombeiroPrivativo bombeiropriva in entry.Value)
                {
                    Console.WriteLine(bombeiropriva.ToString());
                }
            }
        }
        #endregion
        #endregion

    }
}
