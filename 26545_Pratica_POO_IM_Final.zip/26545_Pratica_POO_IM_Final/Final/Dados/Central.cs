﻿/*
    Trabalho Pratico

    Programação Orientada a Objetos (POO)

    João Lima | 2ºANO | LEIM

 */

using ObjetosNegocio;

namespace Dados
{
    [Serializable]
    /// <summary>
    /// Classe responsável por operações relacionadas a central, neste caso, ocorrencia.
    /// </summary>
    public class Central
    {
        #region Attributes
        /// <summary>
        /// Dicionário estático para armazenar ocorrências, onde a chave é um identificador (int) e o valor é uma instância de Ocorrencia.
        /// </summary>
        private static Dictionary<int, Ocorrencia> ocorrencias;
        private static Dictionary<int, Ocorrencia> cloneocorrencias;

        #endregion

        #region Constructors
        /// <summary>
        /// Construtor estático da classe Central.
        /// </summary>
        static Central()
        {
            ocorrencias = new Dictionary<int, Ocorrencia>();
            cloneocorrencias = new Dictionary<int, Ocorrencia>();

        }
        #endregion

        #region Methods
        /// <summary>
        /// Insere ou atualiza uma ocorrência no dicionário de ocorrências.
        /// </summary>
        /// <param name="id">Identificador da ocorrência.</param>
        /// <param name="o">Instância de Ocorrencia a ser inserida ou atualizada.</param>
        /// <returns>True se a ocorrência foi inserida ou atualizada; False se a ocorrência já existe e é igual à nova ocorrência.</returns>
        public static bool InsereOcorrencia(int id, Ocorrencia o)
        {
            if (!ocorrencias.ContainsKey(id))
            {
                ocorrencias.Add(id, o);
                return true;
            }

            if (!ocorrencias[id].Equals(o))
            {
                ocorrencias[id] = o;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Método para inserir uma ocorrência na coleção 'ocorrencias' se o ID ainda não existir.
        /// </summary>
        /// <param name="o">A ocorrência a ser inserida.</param>
        /// <returns>Retorna verdadeiro se a ocorrência for inserida com sucesso, falso se um ID duplicado for detectado.</returns>
        public static bool InsereOcorrenciaSemId(Ocorrencia o)
        {
            if (!ocorrencias.ContainsKey(o.Id))
            {
                ocorrencias.Add(o.Id, o);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Verifica se uma ocorrência com o identificador especificado existe e é igual à ocorrência fornecida.
        /// </summary>
        /// <param name="id">Identificador da ocorrência a ser verificada.</param>
        /// <param name="o">Instância de Ocorrencia a ser comparada.</param>
        /// <returns>True se a ocorrência existe e é igual à ocorrência fornecida; False se a ocorrência não existe.</returns>
        public static bool ExisteOcorrencia(int id, Ocorrencia o)
        {
            if (ocorrencias.ContainsKey(id))
            {
                return ocorrencias[id].Equals(o);
            }

            throw new Exception("A Ocorrencia não existe");
        }

        /// <summary>
        /// Remove uma ocorrência do dicionário de ocorrências se existir e for igual à ocorrência fornecida.
        /// </summary>
        /// <param name="id">Identificador da ocorrência a ser removida.</param>
        /// <param name="o">Instância de Ocorrencia a ser removida.</param>
        /// <returns>True se a ocorrência foi removida; False se a ocorrência não existe ou não é igual à fornecida.</returns>
        public static bool RemoveOcorrencia(int id, Ocorrencia o)
        {
            if (ocorrencias.ContainsKey(id) && ocorrencias[id].Equals(o))
            {
                ocorrencias.Remove(id);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Método para salvar informações de ocorrências em um arquivo binário.
        /// </summary>
        /// <param name="fileName">O nome do arquivo no qual as ocorrências serão salvas.</param>
        /// <returns>Retorna verdadeiro se a operação for bem-sucedida e falso em caso de falha.</returns>
        public static bool SalvaOcorrencia(string fileName)
        {
            try
            {
                using (FileStream fileStream = new FileStream(fileName, FileMode.Create))
                using (BinaryWriter binaryWriter = new BinaryWriter(fileStream))
                {
                    foreach (var ocorrencia in ocorrencias.Values)
                    {
                        binaryWriter.Write(ocorrencia.Id);
                        binaryWriter.Write((int)ocorrencia.Tipo);
                        binaryWriter.Write(ocorrencia.Data.Ticks);
                        binaryWriter.Write(ocorrencia.Localizacao);
                        binaryWriter.Write(ocorrencia.Estado);
                        binaryWriter.Write(ocorrencia.Nivel);
                    }
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        /// <summary>
        /// Método responsável por criar e devolver um clone do dicionário de Ocorrências existente.
        /// </summary>
        /// <returns>Um novo dicionário que é um clone do dicionário original de Ocorrências.</returns>
        public static Dictionary<int, List<Ocorrencia>> CloneDictionaryOcorrencia()
        {
            Dictionary<int, List<Ocorrencia>> cloneocorrencias = ocorrencias
                .ToDictionary(entry => entry.Key, entry => new List<Ocorrencia> { entry.Value });

            return cloneocorrencias;
        }

        /// <summary>
        /// Método responsável por mostrar no console as informações contidas no dicionário de Ocorrências.
        /// </summary>
        public static void ShowDictinaryOcorrencia()
        {
            Dictionary<int, List<Ocorrencia>> cloneocorrencias = Central.CloneDictionaryOcorrencia();

            foreach (KeyValuePair<int, List<Ocorrencia>> entry in cloneocorrencias)
            {
                Console.WriteLine($"ID: {entry.Key}");

                foreach (Ocorrencia ocorrencia in entry.Value)
                {
                    Console.WriteLine(ocorrencia.ToString());
                }
            }
        }
        #endregion

    }
}
